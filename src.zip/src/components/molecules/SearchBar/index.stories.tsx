import { ComponentStory, ComponentMeta } from "@storybook/react";
import React from "react";
import SearchBar from ".";
import search from "../../../images/search.svg";

export default {
  title: "Application/Molecules/SearchBar",
  component: SearchBar,
} as ComponentMeta<typeof SearchBar>;

const Template: ComponentStory<typeof SearchBar> = (args) => <SearchBar {...args} />;

export const searchBar = Template.bind({});
searchBar.args = {
  src: search,
  alt: "search icon",
  placeholder: "Search by title or author",
  variant: "standard",
};
