import React from "react";

import { render, screen } from "@testing-library/react";
import SearchBar from ".";
import search from "../../../images/search.svg";

describe("Testing SearchBar component", () => {
  test("testing searchbar", () => {
    render(
      <SearchBar
        src={search}
        alt="search icon"
        variant="standard"
        placeholder="Search by title or author"
      />
    );
    const testingSearchBar = screen.getAllByRole("img");
    expect(testingSearchBar).toHaveLength(1);

    const testingTextField = screen.getByPlaceholderText(
      "Search by title or author"
    );
    expect(testingTextField).toBeInTheDocument();
  });
});
