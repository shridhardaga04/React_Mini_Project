import * as React from "react";
import { styled } from "@mui/material/styles";
import Image from "../../atoms/Image";
import TextField from "../../atoms/TextField";
import { theme } from "../../../themes/theme";
import { Box as MUIBox, InputAdornment } from "@mui/material";

const StyledBox = styled(MUIBox)({
  ...theme.typography.h3,
  display: "flex",
  alignItems: "center",
  justifyItems: "baseline",
  width: "658px",
});

const StyledImage = styled(Image)({});

const StyledTextField = styled(TextField)({});

interface SearchBarProps {
  src: string;
  alt: string;
  variant: any;
  placeholder: string;
  startAdornment?: any;
}

const SearchBar = ({ src, alt, variant, placeholder }: SearchBarProps) => {
  return (
    <StyledBox>
      <StyledTextField
        variant={variant}
        placeholder={placeholder}
        InputProps={{
          style: {
            fontWeight: 600,
            fontSize: "22px",
          },
          startAdornment: (
            <InputAdornment position="start" style={{ marginRight: "3%" }}>
              <StyledImage src={src} alt={alt} />
            </InputAdornment>
          ),
        }}
      />
    </StyledBox>
  );
};

export default SearchBar;
