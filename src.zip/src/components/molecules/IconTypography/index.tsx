import * as React from "react";
import { styled } from "@mui/material/styles";
import { Box, BoxProps } from "@mui/material";
import Image from "../../atoms/Image";
import TypographyComp from "../../atoms/Typography";

import { theme } from "../../../themes/theme";

const StyledBox = styled(Box)({
  display: "flex",
  color: theme.palette.info.main,
  textTransform: "none",
});

const StyledBox2 = styled(Box)({
  marginRight: "4px",
});

interface IconTypoProps extends BoxProps {
  src: string;
}

const style = {
  typo: {
    marginRight: "26px",
  },
};

const IconTypo = ({ children, src, ...rest }: IconTypoProps) => {
  return (
    <StyledBox {...rest} data-testid={children}>
      <StyledBox2>
        <Image src={src} alt="icon" />{" "}
      </StyledBox2>
      <TypographyComp variant="h6" sx={style.typo}>
        {children}
      </TypographyComp>
    </StyledBox>
  );
};

export default IconTypo;
