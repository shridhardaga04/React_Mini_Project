import React from "react";

import { render, screen } from "@testing-library/react";
import IconTypo from ".";
import icon from "../../../images/time.svg";

describe("Testing IconTypo component", () => {
  test("testing", () => {
    render(<IconTypo src={icon} />);
    const testingIconTypo = screen.getAllByRole("img");
    expect(testingIconTypo).toHaveLength(1);

    const testingText = screen.getAllByRole("heading");
    expect(testingText).toHaveLength(1);
  });
});
