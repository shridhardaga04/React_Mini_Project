import React from "react";
import { ComponentStory, ComponentMeta } from "@storybook/react";
import IconTypo from ".";
import icon from "../../../images/time.svg";

export default {
  title: "Application/Molecules/IconText",
  component: IconTypo,
} as ComponentMeta<typeof IconTypo>;

const Template: ComponentStory<typeof IconTypo> = (args) => <IconTypo {...args} />;

export const iconText = Template.bind({});
iconText.args = {
  children: "13-minute read",
  src: icon,
};
