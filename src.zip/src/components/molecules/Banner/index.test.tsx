import React from "react";

import { render, screen } from "@testing-library/react";
import Banner from ".";
import image from "../../../images/undraw_Reading.svg";

describe("Testing Banner", () => {
  test("testing banner", () => {
    render(<Banner src={image} alt="Reading Image" />);
    const testingBanner = screen.getAllByRole("img");
    expect(testingBanner).toHaveLength(1);

    const banner = screen.getAllByRole("heading");
    expect(banner).toHaveLength(2);
  });
});
