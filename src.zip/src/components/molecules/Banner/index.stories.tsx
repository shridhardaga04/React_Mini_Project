import { ComponentStory, ComponentMeta } from "@storybook/react";
import React from "react";
import Banner from ".";
import image from "../../../images/undraw_Reading.svg";

export default {
  title: "Application/Molecules/Banner",
  component: Banner,
} as ComponentMeta<typeof Banner>;

const Template: ComponentStory<typeof Banner> = (args) => <Banner {...args} />;

export const banner = Template.bind({});
banner.args = {
  src: image,
  alt: "Reading Image",
//   sx: { paddingLeft: "200%" },
};
