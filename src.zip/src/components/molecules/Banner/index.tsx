import * as React from "react";
import { styled } from "@mui/material/styles";
import Image from "../../atoms/Image";
import TypographyComp from "../../atoms/Typography";
import { theme } from "../../../themes/theme";
import { Box as MUIBox } from "@mui/material";

const StyledBox = styled(MUIBox)({
  display: "flex",
  textTransform: "none",
  width: "912px",
  height: "264px",
  background: "#F1F6F4",
  justifyContent: "space-around"
});

const StyledBox2 = styled(MUIBox)({
  flexDirection: "column",
});

const StyledTypography1 = styled(TypographyComp)({
  color: theme.palette.text.primary,
  width: "319px",
  height: "90px",
  marginTop: "7%",
});

const StyledTypography2 = styled(TypographyComp)({
  color: theme.palette.info.main,
  height: "69px",
  width: "461px",
  marginTop: "2%",
});

const StyledImage = styled(Image)({
});

interface BannerProps {
  src: string;
  alt: string;
  sx?: any;
}

const Banner = ({ src, ...rest }: BannerProps) => {
  return (
    <StyledBox>
      <StyledBox2>
        <StyledTypography1 variant="h1">
          Explore Books on entrepreneurship
        </StyledTypography1>
        <StyledTypography2 variant="subtitle2">
          Everything you need to know about thriving on a shoestring budget,
          making your first million, and hiring right from the start.
        </StyledTypography2>
      </StyledBox2>

      <StyledImage src={src} {...rest} />
    </StyledBox>
  );
};

export default Banner;
