import * as React from "react";
import { styled } from "@mui/material/styles";
import { StandardTextFieldProps, TextField as MUITextField } from "@mui/material";
import { theme } from "../../../themes/theme";

const StyledTextField = styled(MUITextField)({
  ...theme.typography.body2,
});

interface ITextFieldProps extends StandardTextFieldProps {
  placeholder: string;
  variant: any;
  InputProps?: any
}

const TextField = ({ placeholder, ...rest }: ITextFieldProps) => {
  return <StyledTextField {...rest} placeholder={placeholder} fullWidth />;
};

export default TextField;
