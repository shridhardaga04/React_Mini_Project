import { ComponentStory, ComponentMeta } from "@storybook/react";
import TextField from ".";

export default {
  title: "Application/Atoms/TextField",
  component: TextField,
} as ComponentMeta<typeof TextField>;

const Template: ComponentStory<typeof TextField> = (args) => (
  <TextField {...args} />
);

export const Default = Template.bind({});
Default.args = {
  placeholder: "Search by title or author",
  variant: "standard",
};

