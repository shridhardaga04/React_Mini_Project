import * as React from "react";
import { render, screen } from "@testing-library/react";
import TextField from ".";

describe("Testing the TextField", () => {
  test("TextField element", () => {
    render(<TextField placeholder="Search by title or author" variant={"standard"}/>);
    const textField = screen.getByPlaceholderText("Search by title or author" );
    expect(textField).toBeInTheDocument();
  });
});
