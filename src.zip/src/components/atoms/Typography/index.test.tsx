import React from "react";

import { render, screen } from "@testing-library/react";
import TypographyComp from ".";

describe("primary typography", () => {
  test("library", () => {
    render(<TypographyComp children="My Library" variant="h1" />);
    const library = screen.getByRole(`heading`, { name: `My Library` });
    expect(library).toMatchSnapshot();
  });
});
