import { ComponentStory, ComponentMeta } from "@storybook/react";
import React from "react";
import TypographyComp from ".";
import { theme } from "../../../themes/theme";

export default {
  title: "Application/Atoms/Typography",
  component: TypographyComp,
} as ComponentMeta<typeof TypographyComp>;

const Template: ComponentStory<typeof TypographyComp> = (args) => (
  <TypographyComp {...args} />
);

export const heading1 = Template.bind({});
heading1.args = {
  variant: "h1",
  children: "My Library",
  sx: { color: theme.palette.text.primary },
};

export const authorName = Template.bind({});
authorName.args = {
  variant: "body1",
  children: "Jim Collins & Bill Lazier",
  sx: { color: theme.palette.info.main },
};

export const synopsis = Template.bind({});
synopsis.args = {
  variant: "body2",
  children:
    "Beyond Entrepreneurship 2.0 (2020) updates Jim Collins and Bill Lazier’s essential 1992 business handbook, Beyond Entrepreneurship for the entrepreneurs, visionaries, and innovators of today. This new edition combines the timeless business advice and strategy of the original text, supplemented with cutting-edge insights and case studies pertinent to today’s business world.",
  sx: {
    color: theme.palette.text.primary,
    width: "600px",
    height: "100px",
    left: "264px",
    top: "624px",
  },
};

export const BookName = Template.bind({});
BookName.args = {
  variant: "subtitle1",
  children: "Beyond Entrepreneurship",
  sx: { color: theme.palette.text.primary },
};

export const subtitle2 = Template.bind({});
subtitle2.args = {
  variant: "subtitle2",
  children: "Turning Your Business into an Enduring Great Company",
  sx: { color: theme.palette.text.primary },
};

export const footerSub = Template.bind({});
footerSub.args = {
  variant: "h2",
  children: "Big ideas in small packages Start learnign now",
  sx: { color: theme.palette.secondary.main },
};

export const minutesRead = Template.bind({});
minutesRead.args = {
  variant: "h6",
  children: "13 minutes read",
  sx: { color: theme.palette.info.main },
};
