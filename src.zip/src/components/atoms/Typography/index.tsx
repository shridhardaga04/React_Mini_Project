import * as React from "react";
import { styled } from "@mui/material/styles";
import { Typography as MUITypography, TypographyProps } from "@mui/material";

const StyledTypography = styled(MUITypography)({
  textTransform: "none",
});

interface ITypographyProps extends TypographyProps {
  component?: string;
}

const TypographyComp = ({ children, component, ...rest }: ITypographyProps) => {
  return (
    <StyledTypography {...rest} data-testid={children}>
      {children}
    </StyledTypography>
  );
};

export default TypographyComp;
