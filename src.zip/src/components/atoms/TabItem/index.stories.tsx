import { ComponentStory, ComponentMeta } from "@storybook/react";
import React from "react";
import Tab from ".";
import { theme } from "../../../themes/theme";

export default {
  title: "Application/Atoms/Tab",
  component: Tab,
} as ComponentMeta<typeof Tab>;

const Template: ComponentStory<typeof Tab> = (args) => <Tab {...args} />;

export const Default = Template.bind({});
Default.args = {
  label: "currently reading",
  value: 0,
  sx: {
    color: theme.palette.primary.light,
    borderBottom: 2,
    borderColor: theme.palette.primary.light,
    // marginBottom: 0, 
  },
};
