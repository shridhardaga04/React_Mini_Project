import * as React from "react";
import { render, screen } from "@testing-library/react";
import Tab from ".";

describe("Testing the Tab", () => {
  test("tab element", () => {
    render(<Tab label="currently reading"/>);
    const tab = screen.getByRole(`tab`, { name: "currently reading" });
    expect(tab).toBeInTheDocument();
  });
});
