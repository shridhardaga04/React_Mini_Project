import * as React from "react";
import { styled } from "@mui/material/styles";
import { Tab as MUITab, Tabs, TabProps } from "@mui/material";
import { theme } from "../../../themes/theme";

const StyledTab = styled(MUITab)({
  ...theme.typography.subtitle1,
  textTransform: "none",
});


interface ITabProps extends TabProps {}

const Tab = ({ label, ...rest }: ITabProps) => {
  return (
    <Tabs value='0'>
      <StyledTab label={label} {...rest} value='0'/>
    </Tabs>
  );
};

export default Tab;
