import * as React from "react";
import { styled } from "@mui/material/styles";
import { Button as MUIButton, ButtonProps } from "@mui/material";
import { theme } from "../../../themes/theme";

const StyledButton = styled(MUIButton)({
  ...theme.typography.body1,
  textTransform: "none",
  borderRadius: "4px",
  width: "284px",
  height: "26px",
});

interface IButtonProps extends ButtonProps {
  children: string;
  onClick?: any;
  id?: any;
}

const Button = ({ children, onClick, id, ...rest }: IButtonProps) => {

  return (
    <StyledButton
      {...rest}
      data-testid={children}
      onClick={() => {onClick(id)}}
    >
      {children}
    </StyledButton>
  );
};

export default Button;
