import * as React from "react";
import { fireEvent, render, screen } from "@testing-library/react";
import Button from ".";

describe("Testing the Button", () => {
  test("Send to Kindle", () => {
    render(<Button children="Send to Kindle" variant="text" />);
    const sendTo = screen.getByRole(`button`, { name: /Send to Kindle/i });
    expect(sendTo).toBeInTheDocument();
  });

  test("Finished Reading", () => {
    const handleClick = jest.fn();
    render(
      <Button
        children="Finished Reading"
        variant="contained"
        onClick={handleClick}
      />
    );
    const finish = screen.getByRole(`button`, { name: /Finished Reading/i });
    expect(finish).toBeInTheDocument();
    fireEvent.click(finish);
    expect(handleClick).toBeCalled();
  });

});
