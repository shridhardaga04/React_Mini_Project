import React from "react";
import { ComponentStory, ComponentMeta } from "@storybook/react";
import AddIcon from "@mui/icons-material/Add";
import ArrowRightAltIcon from '@mui/icons-material/ArrowRightAlt';
import Button from ".";
import { theme } from "../../../themes/theme";

export default {
  title: "Application/Atoms/Button",
  component: Button,
} as ComponentMeta<typeof Button>;

const Template: ComponentStory<typeof Button> = (args) => <Button {...args} />;

export const Default = Template.bind({});
Default.args = {
  variant: "contained",
  color: "primary",
  sx: { "&:hover": { backgroundColor: theme.palette.primary.dark } },
  children: "Finished Reading",
};

export const Outlined = Template.bind({});
Outlined.args = {
  variant: "outlined",
  children: "Read Now",
  color: "secondary",
  sx: { border: "1px solid #E1ECFC" },
};

export const OutlinedButtonWithIcon = Template.bind({});
OutlinedButtonWithIcon.args = {
  variant: "outlined",
  color: "secondary",
  startIcon: <AddIcon />,
  children: "Add to library",
  sx: {
    "&:hover": {
      backgroundColor: theme.palette.secondary.main,
      color: "white",
    },
  },
};

export const TextButtonWithIcon = Template.bind({});
TextButtonWithIcon.args = {
  variant: "text",
  color: "info",
  endIcon: <ArrowRightAltIcon />,
  children: "Send to Kindle",
};