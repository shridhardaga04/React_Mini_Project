import * as React from "react";
import { styled } from "@mui/material/styles";
import { Avatar as MUIAvatar, AvatarProps } from "@mui/material";
import { theme } from "../../../themes/theme";

const StyledAvatar = styled(MUIAvatar)({
  ...theme.typography.body1,
  textTransform: "none",
});

interface IAvatarProps extends AvatarProps {}

const Avatar = ({ children, ...rest }: IAvatarProps) => {
  return (
    <StyledAvatar {...rest} data-testid={children}>
      {children}
    </StyledAvatar>
  );
};

export default Avatar;
