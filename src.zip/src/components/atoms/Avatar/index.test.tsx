import * as React from "react";
import { render, screen } from "@testing-library/react";
import Avatar from ".";

describe("Testing the Avatar", () => {
  test("avatar", () => {
    render(<Avatar children="A"/>);
    const avatar = screen.getByText("A");
    expect(avatar).toBeInTheDocument();
  });
});
