import { ComponentStory, ComponentMeta } from "@storybook/react";
import Avatar from ".";

export default {
  title: "Application/Atoms/Avatar",
  component: Avatar,
} as ComponentMeta<typeof Avatar>;

const Template: ComponentStory<typeof Avatar> = (args) => <Avatar {...args} />;

export const LetterAvatars = Template.bind({});
LetterAvatars.args = {
  color: "#FDFAFA",
  children: "A",
  sx: { bgcolor: "#69A6E3" },
};
