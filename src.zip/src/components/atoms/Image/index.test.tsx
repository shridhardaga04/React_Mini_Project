import * as React from "react";
import { render, screen } from "@testing-library/react";
import ImageComp from ".";

describe("Testing the ImageComp", () => {
  test("book images and icons", () => {
    render(<ImageComp src={""} alt="any image or icon"/>);
    const images = screen.getByRole(`img`, { name: "any image or icon" });
    expect(images).toBeDefined();
    expect(images).toMatchSnapshot();

  });
});
