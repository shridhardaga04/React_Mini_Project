import React from "react";
import { ComponentMeta, ComponentStory } from "@storybook/react";
import ImageComp from ".";
import image from "../../../images/11.svg";

export default {
  title: "Application/Atoms/Image",
  component: ImageComp,
} as ComponentMeta<typeof ImageComp>;

const Template: ComponentStory<typeof ImageComp> = (args) => (
  <ImageComp {...args} />
);

export const bookImage = Template.bind({});
bookImage.args = {
  src: image,
  alt: "any image or icon",
  style: {opacity: 0.6} 
  
};
