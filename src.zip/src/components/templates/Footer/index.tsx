import * as React from "react";
import { styled } from "@mui/material/styles";
import { theme } from "../../../themes/theme";
import { Box, BoxProps } from "@mui/material";
import Image from "../../atoms/Image";
import TypographyComp from "../../atoms/Typography";
import logo from "../../../images/1.svg";

const FooterBox = styled(Box)({
  background: "#F1F6F4",
  maxHeight: "370px",
  width: "100%",
  left: 0,
  bottom: 0,
});

const StyledBox = styled(Box)({
  display: "flex",
  overflow: "none",
  padding: "2.5%",
});

const LogoBox = styled(Box)({
  width: "25%",
  marginLeft: "10%",
  marginRight: "8%",
});

const StyledLogo = styled(Image)({});

const IdeaTypography = styled(TypographyComp)({
  color: theme.palette.secondary.main,
  marginTop: "9%",
});

const ContentBox = styled(Box)({
  padding: "0 3%",
});

const HeadingTypography = styled(TypographyComp)({
  color: theme.palette.text.primary,
  marginBottom: "10%",
});

const DetailTypography = styled(TypographyComp)({
  color: theme.palette.info.main,
  marginBottom: "10%",
  cursor: "pointer",
});

const StyledBox2 = styled(Box)({
  marginLeft: "10%",
});

interface IBoxProps extends BoxProps {}

const Footer = ({ children, ...rest }: IBoxProps) => {
  return (
    <FooterBox>
      <StyledBox {...rest}>
        <LogoBox>
          <StyledLogo src={logo} alt="logo" />
          <IdeaTypography
            children="Big ideas in small packages Start learnign now"
            variant="h2"
          />
        </LogoBox>

        <ContentBox>
          <HeadingTypography children="Editorial" variant="body2" />
          <DetailTypography children="Book Lists" variant="body2" />
          <DetailTypography children="What is nonfiction?" variant="body2" />
          <DetailTypography children="What to read next" variant="body2" />
          <DetailTypography children="Benefits of reading" variant="body2" />
        </ContentBox>

        <ContentBox>
          <HeadingTypography children="Useful Links" variant="body2" />
          <DetailTypography children="Pricing" variant="body2" />
          <DetailTypography children="Blinkist Business" variant="body2" />
          <DetailTypography children="Gift cards" variant="body2" />
          <DetailTypography children="Blinkist magaine" variant="body2" />
          <DetailTypography children="Contact & help" variant="body2" />
        </ContentBox>

        <ContentBox>
          <HeadingTypography children="Company" variant="body2" />
          <DetailTypography children="About" variant="body2" />
          <DetailTypography children="Careers" variant="body2" />
          <DetailTypography children="Partners" variant="body2" />
          <DetailTypography children="Code of conduct" variant="body2" />
        </ContentBox>
      </StyledBox>

      <StyledBox2>
        <DetailTypography
          children=" © Blinkist 2021 Sitemap | Imprint | Terms of Service | Privacy
    Policies"
          variant="h6"
        />
      </StyledBox2>
    </FooterBox>
  );
};

export default Footer;
