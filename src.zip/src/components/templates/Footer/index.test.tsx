import React from "react";

import { screen, render } from "@testing-library/react";
import Footer from ".";

describe("testing footer", () => {
  test("testing footerBold of footer", () => {
    render(<Footer />);
    const testingImage = screen.getAllByRole(`img`);
    expect(testingImage).toHaveLength(1);
  });
});
