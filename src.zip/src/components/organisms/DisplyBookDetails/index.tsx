import React from "react";
import { Box, BoxProps } from "@mui/material";
import { styled } from "@mui/material/styles";
import TypographyComp from "../../atoms/Typography";
import { theme } from "../../../themes/theme";
import IconTypo from "../../molecules/IconTypography";
import icon from "../../../images/time.svg";
import ImageComp from "../../atoms/Image";
import Button from "../../atoms/Buttons";
import ArrowRightAltIcon from "@mui/icons-material/ArrowRightAlt";
import { useNavigate, useParams } from "react-router-dom";
import axios from "axios";

const MainBox = styled(Box)({
  display: "flex",
});

const IdeaTypography = styled(TypographyComp)({
  color: theme.palette.text.primary,
  marginBottom: "7%",
});

const BookName = styled(TypographyComp)({
  color: theme.palette.text.primary,
  marginBottom: "5%",
});

const BusinessTypography = styled(TypographyComp)({
  color: theme.palette.text.primary,
  marginBottom: "5%",
});

const AuthorName = styled(TypographyComp)({
  color: theme.palette.info.main,
  marginBottom: "3%",
});

const ButtonBox = styled(Box)({
  display: "flex",
  marginTop: "15%",
  alignItems: "baseline",
});

const ImageBox = styled(Box)({
  marginLeft: "12%",
  marginTop: "4%",
});

const ReadButton = styled(Button)({
  width: "120px",
  height: "44px",
  padding: "3% 4%",
  marginRight: "5%",
  borderColor: theme.palette.text.primary,
});

const FinishButton = styled(Button)({
  ...theme.typography.body1,
  background: theme.palette.primary.main,
  color: theme.palette.text.primary,
  width: "170px",
  height: "44px",
  padding: "3% 4%",
  borderRadius: "4px",
  marginRight: "5%",
});

const KindleButton = styled(Button)({
  width: "170px",
  borderRadius: "4px",
  color: theme.palette.info.main,
});

export interface DisplayProps extends BoxProps {}

const DisplayBook: React.FC<DisplayProps> = () => {
  const [data, setData] = React.useState<any>({});
  const navigate = useNavigate();

  let { id } = useParams();
  if (id === undefined) {
    id = "1";
  }

  React.useEffect(() => {
    axios
      .get(`http://localhost:3006/books/${id}`)
      .then((res) => {
        setData(res.data);
      })
      .catch((err) => console.log(`error while fetching id = ${err}`));
  }, [id]);

  const handleRead = async (event: any) => {
    data["status"] = "Reading";

    try {
      const config = {
        headers: {
          "Content-Type": "application/json",
        },
      };
      await axios
        .put(`http://localhost:3006/books/${id}`, data, config)
        .catch((err) =>
          console.log(`error while updating id with read now button = ${err}`)
        );
      navigate("/");
    } catch (error: any) {}
  };

  const handleFinished = async (event: any) => {
    data["status"] = "Finished";

    try {
      const config = {
        headers: {
          "Content-Type": "application/json",
        },
      };
      await axios
        .put(`http://localhost:3006/books/${id}`, data, config)
        .catch((err) =>
          console.log(`error while updating id with finished button = ${err}`)
        );
      navigate("/");
    } catch (error: any) {}
  };

  return (
    <MainBox>
      <Box>
        <IdeaTypography children="Get the key ideas from" variant="body2" />
        <BookName children={data["bookName"]} variant="h1" />
        <BusinessTypography
          children="Turning Your Business into an Enduring Great Company"
          variant="h4"
        />
        <AuthorName children={data["authorName"]} variant="body2" />
        <IconTypo src={icon} children={data["readingTime"]} />

        <ButtonBox>
          <ReadButton
            children="Read now"
            variant="outlined"
            onClick={handleRead}
            disabled={
              data["status"] === "New" || data["status"] === "Finished"
                ? false
                : true
            }
          />

          <FinishButton
            children="Finished Reading"
            variant="contained"
            onClick={handleFinished}
            disabled={data["status"] === "Reading" ? false : true}
          />

          <KindleButton
            children="Send to Kindle"
            variant="text"
            endIcon={<ArrowRightAltIcon />}
          />
        </ButtonBox>
      </Box>

      <ImageBox>
        <ImageComp src={data["images"]} alt="book" />
      </ImageBox>
    </MainBox>
  );
};

export default DisplayBook;
