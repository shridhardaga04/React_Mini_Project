import React from "react";

import { screen, render, fireEvent } from "@testing-library/react";
import DisplayBook from ".";
import { BrowserRouter as Router } from "react-router-dom";

describe("Testing DisplayBook", () => {
  test("testing DisplayBook", () => {
    render(
      <Router>
        <DisplayBook />
      </Router>
    );

    const testingButton = screen.getAllByRole("button");
    expect(testingButton).toHaveLength(3);

    const testingImage = screen.getAllByRole(`img`);
    expect(testingImage).toHaveLength(2);

    const testingHeading = screen.getAllByRole(`heading`);
    expect(testingHeading).toHaveLength(3);

    // const buttonBox = screen.getAllByTestId("buttonBox");
    // expect(buttonBox).toBeDefined();
  });

  test("Read Now Button in card", () => {
    render(
      <Router>
        <DisplayBook />
      </Router>
    );
    // fireEvent.click(screen.getByRole("button", {name : "Read now"}));
    // fireEvent.click(screen.getByRole("button", {name : "Finished Reading"}));

    const readBtn = screen.getByTestId("Read now")
    expect(readBtn).toBeDefined()
    fireEvent.click(readBtn)

    const finishedBtn = screen.getByTestId("Finished Reading")
    expect(finishedBtn).toBeDefined()
    fireEvent.click(finishedBtn)
  });
});
