import { ComponentMeta, ComponentStory } from "@storybook/react";
import React from "react";
import DisplayBook from ".";
import { BrowserRouter as Router } from "react-router-dom";

export default {
  title: "Application/Organism/DisplayBook",
  component: DisplayBook,
} as ComponentMeta<typeof DisplayBook>;

const Template: ComponentStory<typeof DisplayBook> = (args: any) => (
  <Router>
    <DisplayBook {...args} />{" "}
  </Router>
);

export const displayBook = Template.bind({});
displayBook.args = {};
