import React from "react";
import { fireEvent, render, screen } from "@testing-library/react";
import Card from ".";
import image from "../../../images/10.svg";
import { BrowserRouter as Router } from "react-router-dom";

describe("testing Card", () => {
  const src = image;
  const bookName = "Bring your Human to work";
  const authorName = "Erica Keswin";
  const readingTime = "13-Minute read";
  const personRead = "1.9k reads";
  const status = "Reading" || "New" || "Finished";
  const type = "trending" || "newlyAdded" || "featured";

  test("renders Card of testing", () => {
    // const handleClick = jest.fn();
    render(
      <Router>
        <Card
          src={src}
          bookName={bookName}
          authorName={authorName}
          readingTime={readingTime}
          personReading={personRead}
          status={status}
          alt="Book cover Image"
          type={type}
          id="1"
        />
      </Router>
    );
    const card = screen.getByText(bookName);
    expect(card).toBeDefined();
    expect(card).toMatchSnapshot();

    const Finished = screen.getByTestId("Finished")
    expect(Finished).toBeDefined()
    fireEvent.click(Finished)

    // const readAgain = screen.getByRole(`button`, { name: /Read again/i });
    // expect(readAgain).toBeInTheDocument();
    // fireEvent.click(readAgain);
    // expect(handleClick).toBeCalled();
  });
});
