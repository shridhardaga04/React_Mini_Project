import { ComponentStory, ComponentMeta } from "@storybook/react";
import React from "react";
import { BrowserRouter as Router } from "react-router-dom";
import Card from ".";
import image from "../../../images/10.svg";
import AddIcon from "@mui/icons-material/Add";
// import { theme } from "../../../themes/theme";

export default {
  title: "Application/Organism/Card",
  component: Card,
} as ComponentMeta<typeof Card>;

const Template: ComponentStory<typeof Card> = (args) => <Router>
  <Card {...args} /></Router>;

export const card = Template.bind({});
card.args = {
  src: image,
  alt: "Book cover Image",
  startIcon: <AddIcon />,
  // status: "Finished",
  // status: "Reading",
  status: "New",
  personReading: "16k reads",
  bookName: "Bring your Human to work",
  authorName: "Erica Keswin",
  readingTime: "13-Minute time",
  type: "trending",
  // sx: {
  //   "&:hover": {
  //     backgroundColor: theme.palette.secondary.main,
  //     color: "white",
  //   },
  // },
};
