import * as React from "react";
import { styled } from "@mui/material/styles";
import {
  Box,
  Card as MUICard,
  CardActions,
  CardContent,
  CardMedia,
  CardProps,
  LinearProgress,
} from "@mui/material";
import { theme } from "../../../themes/theme";
import icon from "../../../images/time.svg";
import dots from "../../../images/moreHor.svg";
import person from "../../../images/person.svg";
import AddIcon from "@mui/icons-material/Add";
import Image from "../../atoms/Image";
import TypographyComp from "../../atoms/Typography";
import Buttons from "../../atoms/Buttons";
import IconTypography from "../../molecules/IconTypography";
import { useLocation, useNavigate } from "react-router-dom";
import axios from "axios";

const StyledCard = styled(MUICard)({
  height: "466px",
  width: "284px",
  borderRadius: "8px",
  border: "1px solid #E1ECFC",
  margin: 0,
  padding: 0,
  cursor: "pointer",
});

const BookName = styled(TypographyComp)({
  color: theme.palette.text.primary,
  paddingBottom: "6%",
});

const AuthorName = styled(TypographyComp)({
  color: theme.palette.info.main,
  paddingBottom: "6%",
});

const StyledButton = styled(Buttons)({
  ...theme.typography.body1,
  textTransform: "none",
  borderRadius: "4px",
  color: theme.palette.secondary.main,
});

const IconBox = styled(Box)({
  display: "flex",
});

const LinearDotBox = styled(Box)({
  textAlign: "end",
  width: "100%",
});

const StyledLinearProgress = styled(LinearProgress)({
  marginTop: "4px",
  height: "15px",
  background: "#F1F6F4",
  padding: 0,

  "& .MuiLinearProgress-barColorPrimary": {
    backgroundColor: "#E1ECFC ",
  },
  "& .MuiLinearProgress-colorPrimary": {
    backgroundColor: "#F1F6F4",
  },

  borderRadius: "0px 0px 8px 8px",
});

let style = {
  cardContent: {
    marginLeft: "8px",
    padding: "8px",
  },

  cardFooter: {
    padding: 0,
    display: "flex",
    textAllign: "center",
  },

  hover: {
    "&:hover": {
      backgroundColor: theme.palette.secondary.main,
      color: "white",
    },
  },
  cardFooterBorder: {
    borderTop: "1px solid #E1ECFC",
    padding: 0,
    height: "47px",

    "&:hover": {
      backgroundColor: theme.palette.secondary.main,
      color: "white",
    },
  },
};

interface ICardProps extends CardProps {
  src: string;
  alt: string;
  startIcon?: any;
  status: string;
  type: string;
  personReading?: string;
  bookName: string;
  authorName: string;
  readingTime: string;
  sx?: any;
  id: any;
  func?: any;
}

const Card = ({
  src,
  alt,
  status,
  personReading,
  bookName,
  authorName,
  readingTime,
  func,
  id,
  type,
}: ICardProps) => {
  let location = useLocation();

  const [data, setData] = React.useState<any>({});
  const navigate = useNavigate();

  React.useEffect(() => {
    axios
      .get(`http://localhost:3006/books/${id}`)
      .then((res) => {
        setData(res.data);
      })
      .catch((err) => console.log(`error while fetching id = ${err}`));
  }, [id]);

  const handleRead = async (id: any) => {
    data["status"] = "Reading";

    try {
      const config = {
        headers: {
          "Content-Type": "application/json",
        },
      };
      await axios
        .put(`http://localhost:3006/books/${id}`, data, config)
        .catch((err) =>
          console.log(`error while updating id with read now button = ${err}`)
        );
      func();
      navigate("/");
    } catch (error: any) {}
  };

  const handleFinished = async (id: any) => {
    data["status"] = "Finished";

    try {
      const config = {
        headers: {
          "Content-Type": "application/json",
        },
      };

      await axios
        .put(`http://localhost:3006/books/${id}`, data, config)
        .catch((err) =>
          console.log(`error while updating id with finished button = ${err}`)
        );
      func();

      navigate("/");
    } catch (error: any) {}
  };

  return (
    <StyledCard data-testid = "card">
      <CardMedia>
        <Image src={src} alt={alt} />
      </CardMedia>

      <CardContent sx={style.cardContent}>
        <BookName variant="subtitle1">{bookName}</BookName>
        <AuthorName variant="body1">{authorName}</AuthorName>

        <IconBox>
          <IconTypography src={icon} children={readingTime} />

          {personReading && (
            <IconTypography src={person} children={personReading} />
          )}
        </IconBox>
      </CardContent>

      <CardActions disableSpacing sx={style.cardFooter}>
        {status === "Reading" && (
          <LinearDotBox>
            {location.pathname === "/" ? (
              <StyledButton id={id} onClick={(event:any) => handleFinished(event)}>
                Finished
              </StyledButton>
            ) : (
              <Box sx={{ transform: "translate(-5%)" }}>
                <Image src={dots} alt="three dots" />
              </Box>
            )}
            <StyledLinearProgress variant="determinate" value={30} />
          </LinearDotBox>
        )}

        {status === "New" && (
          <StyledButton
            startIcon={<AddIcon />}
            sx={style.cardFooterBorder}
            id={id}
            onClick={(event:any) => handleRead(event)}
          >
            Add to library
          </StyledButton>
        )}

        {status === "Finished" && (
          <LinearDotBox>
            <StyledButton id={id} onClick={(event:any) => handleRead(event)}>
              Read again
            </StyledButton>
            <StyledLinearProgress variant="determinate" value={100} />
          </LinearDotBox>
        )}
      </CardActions>
    </StyledCard>
  );
};

export default Card;
