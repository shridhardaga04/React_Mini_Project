import { ComponentStory, ComponentMeta } from "@storybook/react";
import React from "react";
import NavBar from ".";
import image from "../../../images/1.svg";
import search from "../../../images/search.svg";
import down from "../../../images/down arrow.svg";
import { BrowserRouter as Router } from "react-router-dom";

export default {
  title: "Application/Organism/NavBar",
  component: NavBar,
} as ComponentMeta<typeof NavBar>;

const Template: ComponentStory<typeof NavBar> = (args) => (
  <Router>
    <NavBar {...args} />
  </Router>
);

export const navBar = Template.bind({});
navBar.args = {
  src: image,
  alt: "Image",
  search: search,
  variant: "body1",
  down: down,
};
