import * as React from "react";
import { styled } from "@mui/material/styles";
import { theme } from "../../../themes/theme";
import Image from "../../atoms/Image";
import TypographyComp from "../../atoms/Typography";
import Avatar from "../../atoms/Avatar";
import IconTypography from "../../molecules/IconTypography";
import {
  Box,
  BoxProps,
  // Dialog,
  DialogContent,
  DialogContentText,
  Popover,
} from "@mui/material";

import Enterpreneurship from "../../../images/entrepreneurship.svg";
import Politics from "../../../images/politics.svg";
import Science from "../../../images/science.svg";
import Health from "../../../images/health.svg";
import Development from "../../../images/development.svg";
import Economics from "../../../images/economics.svg";
import History from "../../../images/history.svg";
import Chat from "../../../images/chat.svg";
import Motivation from "../../../images/motivation.svg";
import Education from "../../../images/education.svg";
import Nature from "../../../images/nature and the environment.svg";
import Pschology from "../../../images/psychology.svg";
import Productivity from "../../../images/productivity.svg";
import Wallet from "../../../images/wallet.svg";
import Heart from "../../../images/sex and relationship.svg";
import Bag from "../../../images/corporate culture.svg";
import Marketing from "../../../images/Vector-1.svg";
import Focus from "../../../images/career and success.svg";
import { useNavigate } from "react-router-dom";

const iconList = [
  { icon: Enterpreneurship, label: "Enterpreneurship", id: "1" },
  { icon: Politics, label: "Politics", id: "2" },
  { icon: Marketing, label: "Marketing & Sales", id: "3" },
  { icon: Science, label: "Science", id: "4" },
  { icon: Health, label: "Health & Nutrition", id: "5" },
  { icon: Development, label: "Personal Development", id: "6" },
  { icon: Economics, label: "Economics", id: "18" },
  { icon: History, label: "History", id: "7" },
  { icon: Chat, label: "Communication Skills", id: "8" },
  { icon: Bag, label: "Corporate Culture", id: "9" },
  { icon: Motivation, label: "Motivation & Inspiration", id: "10" },
  { icon: Wallet, label: "Money & Investments", id: "11" },
  { icon: Pschology, label: "Psychology", id: "12" },
  { icon: Productivity, label: "Productivity", id: "13" },
  { icon: Heart, label: "Sex & Relationship", id: "14" },
  { icon: Nature, label: "Nature & Environment", id: "15" },
  { icon: Education, label: "Education", id: "16" },
  { icon: Focus, label: "career & sucess", id: "17" },
];

const StyledBox = styled(Box)({
  width: "100vw",
  display: "flex",
  alignItems: "baseline",
  marginTop: "1.5%",
  position: "sticky",
});

const LogoBox = styled(Box)({
  alignSelf: "center",
  marginLeft: "10%",
  marginRight: "3.5%",
});

const SearcBox = styled(Box)({
  alignSelf: "center",
  marginRight: "3.5%",
});

const StyledAvatar = styled(Avatar)({
  color: "#FDFAFA",
  background: "#69A6E3",
  fontFamily: "Inter",
  fontSize: "18px",
  fontWeight: 500,
});

const AvatarBox = styled(Box)({
  display: "flex",
  marginLeft: "25%",
  marginRight: "10%",
  alignItems: "center",
});

const StyledPop = styled(Popover)({});

const StyledDialogContent = styled(DialogContent)({
  background: "#F1F6F4",
  height: 398,
  margin: "0 15%",
});

const LineBox = styled(Box)({
  width: "800px",
  border: "1px solid #042330",
  margin: "1.5% 4%",
});

const DialogContentBox1 = styled(Box)({
  width: "800px",
  display: "grid",
  gridTemplateColumns: "1fr 1fr 1fr",
  margin: "1% 6%",
});

const DialogContentBox2 = styled(Box)({
  width: "800px",
  display: "grid",
  gridTemplateColumns: "1fr 1fr 1fr",
  height: "300px",
  margin: "1% 7%",
});

let style = {
  typo: {
    display: "flex",
    color: theme.palette.text.primary,
    marginRight: "3%",
    padding: 0,
    cursor: "pointer",
  },

  icons: {
    marginRight: "2%",
    cursor: "pointer",
  },

  colorTypo: {
    color: theme.palette.secondary.main,
    fontWeight: 700,
  },
};

const dialogTypo = [
  { label: "See Recently Added title", id: "1" },
  { label: "See popular Titles", id: "2" },
];

interface INavBarProps extends BoxProps {
  src: string;
  alt: string;
  search: string;
  variant: any;
  down: string;
}

const NavBar = ({ src, alt, search, variant, down }: INavBarProps) => {
  const [open, setOpen] = React.useState(false);

  const handleOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  const navigate = useNavigate();

  const openMyLibrary = (event: any) => {
    if (event.target.innerText === "My Library") navigate("/");
  };

  const openEnterpreneurship = (event: any) => {
    if (event.target.innerText === "Enterpreneurship") navigate("/explore");
  };

  return (
    <StyledBox>
      <LogoBox>
        <Image src={src} alt={alt} />
      </LogoBox>

      <SearcBox>
        <Image src={search} alt={alt} />
      </SearcBox>

      <TypographyComp
        variant={variant}
        sx={style.typo}
        onClick={() => handleOpen()}
      >
        Explore{" "}
        <Image
          src={down}
          alt="exploreArrow"
          onClick={handleOpen}
          sx={style.icons}
        />
      </TypographyComp>

      <TypographyComp
        variant={variant}
        sx={style.typo}
        onClick={(event: any) => openMyLibrary(event)}
      >
        My Library
      </TypographyComp>
      <AvatarBox>
        <StyledAvatar children="A" />
        <Image src={down} alt={alt} />
      </AvatarBox>
      <StyledPop
        open={open}
        onClose={handleClose}
        anchorReference="anchorPosition"
        anchorPosition={{ top: 70, left: 70 }}
        data-testid="popOver"
        PaperProps={{
          style: { width: "100%", background: "#F1F6F4" },
        }}
      >
        <StyledDialogContent>
          <DialogContentText>
            <DialogContentBox1>
              <TypographyComp
                children={"Explore by category"}
                sx={style.colorTypo}
              />
              {dialogTypo &&
                dialogTypo.map((item) => (
                  <TypographyComp children={item.label} key={item.id} />
                ))}
            </DialogContentBox1>

            <LineBox />
          </DialogContentText>

          <DialogContentText>
            <DialogContentBox2>
              {iconList &&
                iconList.map((item) => (
                  <IconTypography
                    src={item.icon}
                    children={item.label}
                    sx={style.icons}
                    key={item.id}
                    onClick={(event: any) => openEnterpreneurship(event)}
                  />
                ))}
            </DialogContentBox2>
          </DialogContentText>
        </StyledDialogContent>
      </StyledPop>
    </StyledBox>
  );
};

export default NavBar;
