import React from "react";
import image from "../../../images/1.svg";
import search from "../../../images/search.svg";
import down from "../../../images/down arrow.svg";
import { screen, render, fireEvent } from "@testing-library/react";
import NavBar from ".";
import { BrowserRouter as Router } from "react-router-dom";

describe("Testing NavBar", () => {
  test("render NavBar component", () => {
    render(
      <Router >
        <NavBar
          src={image}
          alt="Image"
          search={search}
          variant="body1"
          down={down}
        />
      </Router>
    );

    const testingImg = screen.getAllByRole(`img`);
    expect(testingImg).toHaveLength(4);

    fireEvent.click(screen.getByText(/Explore/i));
    fireEvent.click(screen.getByText(/My Library/i));
    fireEvent.click(screen.getByText(/Enterpreneurship/i));
    fireEvent.click(screen.getByTestId(/popOver/i));
    fireEvent.click(screen.getByAltText(/exploreArrow/i));


    // const testingHeader = screen.getAllByRole(`heading`);
    // expect(testingHeader).toHaveLength(3);

  });
});