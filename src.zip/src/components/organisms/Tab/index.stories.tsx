import { ComponentMeta, ComponentStory } from "@storybook/react";
import React from "react";
import TabComp from ".";
import { BrowserRouter as Router } from "react-router-dom";

export default {
  title: "Application/Organism/Tab",
  component: TabComp,
} as ComponentMeta<typeof TabComp>;

const Template: ComponentStory<typeof TabComp> = (args: any) => (
  <Router>
    <TabComp {...args} />
  </Router>
);

export const tab = Template.bind({});
tab.args = {};
