import React from "react";
import { fireEvent, render, screen } from "@testing-library/react";
import TabComp from ".";
import { BrowserRouter as Router } from "react-router-dom";

describe("Testing TabComp", () => {
  beforeEach(() => jest.clearAllMocks());

  test("render TabComp component", async () => {
    render(
      <Router>
        <TabComp />
      </Router>
    );

    const testingTablist = screen.getByRole("tablist");
    expect(testingTablist).toBeInTheDocument();
    fireEvent.change(testingTablist)

    // const testingTab = screen.getAllByRole("tab");
    // expect(testingTab).toHaveLength(2);

    // const testingTabPanel = screen.getByRole("tabpanel");
    // expect(testingTabPanel).toBeInTheDocument();
    
    const testingTabPanel = screen.getAllByRole("tabpanel");
    expect(testingTabPanel).toHaveLength(1);

    // const card = screen.getAllByTestId("cardTest");
    // expect(card).toBeDefined();
  });

  test("testing tab for condition", async () => {
    render(
      <Router>
        <TabComp />
      </Router>
    );

    const testingFInished = screen.getByText("Currently reading");
    expect(testingFInished).toBeDefined();
  });
  test("testing tab for finished", async () => {
    render(
      <Router>
        <TabComp />
      </Router>
    );

    const testingFInished = screen.getByText("Finished");
    expect(testingFInished).toBeDefined();
  });
});
