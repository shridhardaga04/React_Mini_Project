import { Box, Tab } from "@mui/material";
import { styled } from "@mui/material/styles";
import TabContext from "@mui/lab/TabContext";
import TabList from "@mui/lab/TabList";
import TabPanel from "@mui/lab/TabPanel";
import BookCard from "../Card";
import React from "react";
import { Link } from "react-router-dom";
import axios from "axios";

export interface TabCompProps {}

const MainBox = styled(Box)({
  width: "950px",
});

const StyledBox = styled(Box)({
  textTransform: "capitalize",
  borderBottom: "2px Solid #F1F6F4",
});

const StyledBox1 = styled(Box)({
  display: "flex",
  flexWrap: "wrap",
  width: "100%",
});

const StyledTab = styled(Tab)({
  textTransform: "capitalize",
  alignItems: "flex-start",
  width: "40%",
});

const StyledTab1 = styled(Tab)({
  textTransform: "capitalize",
  alignItems: "flex-start",
  width: "40%",
});

const SingleCard = styled(Box)({
  marginRight: "1.6%",
  marginBottom: "2.6%",
});

const booksFetch = async (setFinished: any, setReading: any) => {
  await axios
    .get(`http://localhost:3006/books`)
    .then((res: { data: any }) => {
      const finishedData = res.data.filter(
        (item: any) => item.status === "Finished"
      );
      setFinished(finishedData);

      const readingdData = res.data.filter(
        (item: any) => item.status === "Reading"
      );
      setReading(readingdData);
    })
    .catch((err: any) => console.log(err));
};

const TabComp: React.FC<TabCompProps> = () => {
  const [value, setValue] = React.useState("1");
  const handleChange = (event: React.SyntheticEvent, newValue: string) => {
    setValue(newValue);
  };

  const [finishedData, setFinished] = React.useState([]);

  const [readingdData, setReading] = React.useState([]);

  React.useEffect(() => {
    booksFetch(setFinished, setReading);
  }, []);

  return (
    <MainBox>
      <TabContext value={value}>
        <StyledBox>
          <TabList
            onChange={handleChange}
            sx={{ width: "70%", display: "flex" }}
          >
            <StyledTab label="Currently reading" value="1" />
            <StyledTab1 label="Finished" value="2" />
          </TabList>
        </StyledBox>

        <TabPanel value="1">
          <StyledBox1 sx={{ flexGrow: 1 }}>
            {readingdData?.map((item) => (
              <SingleCard key={item["id"]}>
                <Link
                  style={{ textDecoration: "none" }}
                  to={`/display/${item["id"]}`}
                >
                  <BookCard
                    key={item["id"]}
                    id={item["id"]}
                    src={item["images"]}
                    bookName={item["bookName"]}
                    authorName={item["authorName"]}
                    readingTime={item["readingTime"]}
                    personReading={item["personRead"]}
                    status={item["status"]}
                    alt={item["alt"]}
                    type={item["type"]}
                    func={() => booksFetch(setFinished, setReading)}
                  />
                </Link>
              </SingleCard>
            ))}
          </StyledBox1>
        </TabPanel>

        <TabPanel value="2">
          <StyledBox1 sx={{ flexGrow: 1 }}>
            {finishedData?.map((item) => (
              <SingleCard key={item["id"]}>
                <Link
                  style={{ textDecoration: "none" }}
                  to={`/display/${item["id"]}`}
                >
                  <BookCard
                    key={item["id"]}
                    id={item["id"]}
                    src={item["images"]}
                    bookName={item["bookName"]}
                    authorName={item["authorName"]}
                    readingTime={item["readingTime"]}
                    personReading={item["personRead"]}
                    status={item["status"]}
                    alt={item["alt"]}
                    type={item["type"]}
                    func={() => booksFetch(setFinished, setReading)}
                  />
                </Link>
              </SingleCard>
            ))}
          </StyledBox1>
        </TabPanel>
      </TabContext>
    </MainBox>
  );
};

export default TabComp;
