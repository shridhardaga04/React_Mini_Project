import React from "react";
import NavBar from "../../components/organisms/NavBar";
import logo from "../../images/1.svg";
import search from "../../images/search.svg";
import down from "../../images/down arrow.svg";
import Footer from "../../components/templates/Footer";
import TypographyComp from "../../components/atoms/Typography";
import { styled } from "@mui/material/styles";
import { Box } from "@mui/material";
import { theme } from "../../themes/theme";
import DisplayBook from "../../components/organisms/DisplyBookDetails";

const MainBox = styled(Box)({
  overflow: "none",
  maxHeight: "100vh",
});

const DisplayBox = styled(Box)({
  marginLeft: "10%",
  marginTop: "4%",
});

const Data = styled(Box)({
  display: "flex",
  marginTop: "4%",
  marginLeft: "10%",
  borderBottom: "1px solid #E1ECFC",
  width: "40%",
});

const StyledBox = styled(Box)({
  width: "22%",
  borderBottom: "2px solid #2CE080",
});

const StyledBox1 = styled(Box)({
  width: "22%",
});

const StyledBox2 = styled(Box)({
  width: "40%",
  marginLeft: "10%",
  marginTop: "1%",
  marginBottom: "4%",
});

const StyledTypo = styled(TypographyComp)({
  color: theme.palette.text.primary,
});

const StyledTypo1 = styled(TypographyComp)({
  ...theme.typography.body2,
  color: theme.palette.info.main,
});

const LineBox = styled(Box)({
  borderBottom: "1px solid #E1ECFC",
  width: "60%",
  marginLeft: "10%",
  marginBottom: "10%",
});

const DisplayBookPage = () => {
  return (
    <MainBox>
      <Box sx={{ transform: "translate(10%)" }}>
        <NavBar
          src={logo}
          alt={"slt"}
          search={search}
          variant={"body1"}
          down={down}
        />

        <DisplayBox>
          <DisplayBook />
       
        </DisplayBox>

        <Data>
          <StyledBox>
            <StyledTypo variant="body1" children="Synposis" />
          </StyledBox>

          <StyledBox1>
            <StyledTypo1 children="Who is it for?" />
          </StyledBox1>

          <StyledBox1>
            <StyledTypo1 children="About the author" />
          </StyledBox1>
        </Data>

        <StyledBox2>
          <StyledTypo
            variant="body2"
            children="Beyond Entrepreneurship 2.0 (2020) updates Jim Collins and Bill Lazier’s essential 1992 business handbook, Beyond Entrepreneurship for the entrepreneurs, visionaries, and innovators of today. This new edition combines the timeless business advice and strategy of the original text, supplemented with cutting-edge insights and case studies pertinent to today’s business world."
          />
        </StyledBox2>

        <LineBox></LineBox>
      </Box>

      <Footer sx={{ marginTop: "2%" }} />
    </MainBox>
  );
};

export default DisplayBookPage;
