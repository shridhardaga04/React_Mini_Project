import React from "react";

import { screen, render } from "@testing-library/react";
import DisplayBookPage from ".";
import { BrowserRouter as Router } from "react-router-dom";

describe("testing DisplayBookPage", () => {
  test("testing button of DisplayBookPage", () => {
    render(
      <Router>
        <DisplayBookPage />
      </Router>
    );

    const testingTypography = screen.getAllByRole("heading");
    expect(testingTypography).toHaveLength(5);

    const testingButton = screen.getAllByRole("button");
    expect(testingButton).toHaveLength(3);

    const testingImage = screen.getAllByRole(`img`);
    expect(testingImage).toHaveLength(7);
  });
});
