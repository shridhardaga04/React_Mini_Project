import React from "react";
import NavBar from "../../components/organisms/NavBar";
import logo from "../../images/1.svg";
import search from "../../images/search.svg";
import down from "../../images/down arrow.svg";
import Footer from "../../components/templates/Footer";
import TabComp from "../../components/organisms/Tab";
import TypographyComp from "../../components/atoms/Typography";
import { styled } from "@mui/material/styles";
import { Box } from "@mui/material";
import { theme } from "../../themes/theme";

const MainBox = styled(Box)({
  overflow: "none",
  maxHeight: "100vh",
});

const Heading = styled(TypographyComp)({
  color: theme.palette.text.primary,
  marginTop: "4%",
  marginLeft: "10%",
});

const Data = styled(Box)({
  marginTop: "4%",
  marginLeft: "10%",
});

const MyLibrary = () => {
  return (
    <MainBox>
      <Box sx={{transform: "translate(10%)"}}>
      <NavBar
        src={logo}
        alt={"slt"}
        search={search}
        variant={"body1"}
        down={down}
      />
      <Heading variant="h1" children="My Library" />
      <Data>
        <TabComp />
      </Data>
      </Box>
      
      <Footer sx={{marginTop: "2%"}} />
    </MainBox>
  );
};

export default MyLibrary;
