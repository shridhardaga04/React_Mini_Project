import React from "react";

import { screen, render } from "@testing-library/react";
import { BrowserRouter as Router } from "react-router-dom";
import MyLibrary from ".";

describe("Testing My Library component", () => {
  test("testing My Library", () => {
    render(
      <Router>
        <MyLibrary />
      </Router>
    );

    const testingMyLibraryHeading = screen.getAllByRole(`heading`);
    expect(testingMyLibraryHeading).toHaveLength(3);

    const testingImage = screen.getAllByRole(`img`);
    expect(testingImage).toHaveLength(5);

    const testingTablist = screen.getAllByRole(`tablist`);
    expect(testingTablist).toHaveLength(1);

    const testingTab = screen.getAllByRole(`tab`);
    expect(testingTab).toHaveLength(2);

    const testPanel = screen.getAllByRole(`tabpanel`);
    expect(testPanel).toHaveLength(1);
  });
});
