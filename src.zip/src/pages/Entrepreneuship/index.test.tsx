import React from "react";
import { render, screen } from "@testing-library/react";
import { BrowserRouter as Router } from "react-router-dom";
import Entrepreneuship from ".";
import db from "../../../db.json";
import axios from "axios";

jest.mock("axios");
const mockedAxios = axios as jest.Mocked<typeof axios>;

describe("testing Entrepreneur", () => {
  test("testing button of Entrepreneuship", async () => {
    mockedAxios.get.mockResolvedValue(db.books);
    render(
      <Router>
        <Entrepreneuship />
      </Router>
    );
    const testingTypography = screen.getAllByRole("heading");
    expect(testingTypography).toHaveLength(4);

    const testingImage = screen.getAllByRole(`img`);
    expect(testingImage).toHaveLength(7);

    // const singleCard = screen.getAllByTestId("singleCard");
    // expect(singleCard).toBeInTheDocument();
  });
});
