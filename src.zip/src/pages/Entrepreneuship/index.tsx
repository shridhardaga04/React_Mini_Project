import React from "react";

import NavBar from "../../components/organisms/NavBar";
import logo from "../../images/1.svg";
import down from "../../images/down arrow.svg";
import Footer from "../../components/templates/Footer";
import { styled } from "@mui/material/styles";
import { Box } from "@mui/material";
import { theme } from "../../themes/theme";
import Banner from "../../components/molecules/Banner";
import banner from "../../images/undraw_Reading.svg";
import SearchBar from "../../components/molecules/SearchBar";
import search from "../../images/search.svg";
import TypographyComp from "../../components/atoms/Typography";
import BookCard from "../../components/organisms/Card";
import { Link } from "react-router-dom";
import axios from "axios";

const MainBox = styled(Box)({
  overflow: "none",
  maxHeight: "100vh",
});

const StyledBox = styled(Box)({
  marginTop: "3%",
  marginBottom: "3%",
  marginLeft: "11%",
});

const StyledTypo = styled(TypographyComp)({
  ...theme.typography.h3,
  color: theme.palette.text.primary,
  marginLeft: "11%",
  marginBottom: "1%",
});

const Data = styled(Box)({
  marginLeft: "10%",
  display: "flex",
  flexWrap: "wrap",
  width: "950px",
});

const SingleCard = styled(Box)({
  marginRight: "1.6%",
  marginBottom: "2.6%",
});

export const fetchBooks = async (
  setTrending: any,
  setNewlyAdded: any,
  setFetured: any
) => {
  await axios
    .get(`http://localhost:3006/books`)
    .then((res: { data: any }) => {
      const trendingData = res.data.filter(
        (item: any) => item.type === "trending"
      );
      setTrending(trendingData);

      const newlyAddedData = res.data.filter(
        (item: any) => item.type === "newlyAdded"
      );
      setNewlyAdded(newlyAddedData);

      const featuredData = res.data.filter(
        (item: any) => item.type === "featured"
      );
      setFetured(featuredData);
    })
    .catch((err: any) => console.log(err));
};

function Entrepreneuship() {
  const [trendingData, setTrending] = React.useState([]);
  const [newlyAddedData, setNewlyAdded] = React.useState([]);
  const [featuredData, setFetured] = React.useState([]);

  React.useEffect(() => {
    fetchBooks(setTrending, setNewlyAdded, setFetured);
  }, []);

  return (
    <MainBox>
      <Box sx={{ transform: "translate(10%)" }}>
        <NavBar
          src={logo}
          alt={"logo"}
          search={search}
          variant={"body1"}
          down={down}
        />
        <StyledBox>
          <Banner src={banner} alt="banner" />
        </StyledBox>
        <StyledBox>
          <SearchBar
            src={search}
            alt="search icon"
            variant="standard"
            placeholder="Search by title or author"
          />
        </StyledBox>

        <StyledTypo children="Trending blinks" />

        <Data sx={{ flexGrow: 1 }}>
          {trendingData?.map((item: any) => (
            <SingleCard key={item["id"]} data-testid="singleCard">
              <Link
                style={{ textDecoration: "none" }}
                to={`/display/${item["id"]}`}
              >
                <BookCard
                  key={item["id"]}
                  id={item["id"]}
                  src={item["images"]}
                  bookName={item["bookName"]}
                  authorName={item["authorName"]}
                  readingTime={item["readingTime"]}
                  personReading={item["personRead"]}
                  status={item["status"]}
                  alt={item["alt"]}
                  type={item["type"]}
                />{" "}
              </Link>
            </SingleCard>
          ))}
        </Data>

        <StyledTypo
          children="Just added"
          sx={{ marginBottom: "2%", marginTop: "3%" }}
        />

        <Data sx={{ flexGrow: 1 }}>
          {newlyAddedData?.map((item: any) => (
            <SingleCard key={item["id"]} data-testid="singleCard">
              <Link
                style={{ textDecoration: "none" }}
                to={`/display/${item["id"]}`}
              >
                <BookCard
                  key={item["id"]}
                  id={item["id"]}
                  src={item["images"]}
                  bookName={item["bookName"]}
                  authorName={item["authorName"]}
                  readingTime={item["readingTime"]}
                  personReading={item["personRead"]}
                  status={item["status"]}
                  alt={item["alt"]}
                  type={item["type"]}
                />{" "}
              </Link>
            </SingleCard>
          ))}
        </Data>

        <StyledTypo
          children="Fetured audio blinks"
          sx={{ marginBottom: "2%", marginTop: "3%" }}
        />

        <Data sx={{ flexGrow: 1 }}>
          {featuredData.map((item) => (
            <SingleCard key={item["id"]} data-testid="singleCard">
              <BookCard
                key={item["id"]}
                id={item["id"]}
                src={item["images"]}
                bookName={item["bookName"]}
                authorName={item["authorName"]}
                readingTime={item["readingTime"]}
                personReading={item["personRead"]}
                status={item["status"]}
                alt={item["alt"]}
                type={item["type"]}
              />
            </SingleCard>
          ))}
        </Data>
      </Box>

      <Footer sx={{ marginTop: "2%" }} />
    </MainBox>
  );
}

export default Entrepreneuship;
