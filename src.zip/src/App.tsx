import "./App.css";
import { ThemeProvider } from "@mui/material/styles";
import { theme } from "./themes/theme";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import MyLibrary from "./pages/MyLibrary";
import Entrepreneuship from "./pages/Entrepreneuship";
import DisplayBook from "./pages/DisplyBook";

function App() {
  return (
    <ThemeProvider theme={theme}>
      <div data-testid="App">
        <Router>
          <Routes>
            <Route path="/" element={<MyLibrary />} />
            <Route path="/explore" element={<Entrepreneuship />} />
            <Route path="/display/:id" element={<DisplayBook />} />
          </Routes>
        </Router>
      </div>
      {/* <div className="App">BLINKIST APPLICATION</div> */}
    </ThemeProvider>
  );
}

export default App;
