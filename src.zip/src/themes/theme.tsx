import { createTheme } from "@mui/material/styles";

export const theme = createTheme({
  palette: {
    //Green shade
    primary: {
      main: "#2CE080",
      light: "#22C870",
      dark: "#20BA68",
    },
    // Blue shade
    secondary: {
      main: "#0365F2",
    },
    // Grey shade
    info: {
      main: "#6D787E",
    },
    // typography
    text: {
      primary: "#03314B",
    },
  },
  typography: {
    fontFamily: ["Cera Pro", "sans-serif"].join(","),

    body1: {
      fontWeight: 500,
      fontSize: 16,
      // lineHeight: 20.11,
    },

    body2: {
      fontWeight: 400,
      fontSize: 16,
      // lineHeight: 24,
    },

    subtitle1: {
      fontWeight: 700,
      fontSize: 18,
    },

    subtitle2: {
      fontWeight: 400,
      fontSize: 18,
      // lineHeight: 25,
    },

    h1: {
      fontWeight: 700,
      fontSize: "36px",
      // lineHeight: '45px',
    },

    /* heading 3 */
    h3: {
      fontWeight: 700,
      fontSize: "24px",
      // lineHeight: '45px',
    },

    /* beta/subtitle 1 */
    h2: {
      fontWeight: 500,
      fontSize: "24px",
      // lineHeight: '32px',
    },
    
    h4: {
      fontWeight: 400,
      fontSize: "20px",
      // lineHeight: '32px',
    },

    /* Caption 3 */
    h6: {
      fontWeight: 400,
      fontSize: "14px",
      // lineHeight: '32px',
    },
  },
});
